# 19x + 920071380y = 1
--------------------------------------------------------
def ext_euclid ( a , b ):
    if (b == 0):
        return 1, 0, a
    else:
        x , y , q = ext_euclid( b , a % b )
        x , y = y, ( x - (a // b) * y )
        return x, y, q
print ext_euclid(19, 920071380);