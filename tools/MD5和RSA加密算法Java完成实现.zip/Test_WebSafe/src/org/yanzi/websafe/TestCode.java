package org.yanzi.websafe;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import org.md5.util.MD5Util;
import org.rsa.util.RSAUtil;

public class TestCode {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/****************************RSA���ܽ��ܲ���********************************/					
					try {
				RSAUtil rsa = new RSAUtil();
				String str = "yanzi1225627";
				RSAPublicKey pubKey = rsa.getRSAPublicKey();
				RSAPrivateKey priKey = rsa.getRSAPrivateKey();
				byte[] enRsaBytes = rsa.encrypt(pubKey,str.getBytes());
				String enRsaStr = new String(enRsaBytes, "UTF-8");
				System.out.println("���ܺ�==" + enRsaStr);
				System.out.println("���ܺ�==" + new String(rsa.decrypt(priKey, rsa.encrypt(pubKey,str.getBytes()))));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		/************************************MD5���ܲ���*****************************/
/*		String srcString = "yanzi1225627";
		System.out.println("MD5���ܺ� = " + MD5Util.getMD5String(srcString));*/

	}

}
