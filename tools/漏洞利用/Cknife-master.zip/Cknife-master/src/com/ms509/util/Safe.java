package com.ms509.util;

public final class Safe {
	public static String SPL;
	public static String SPR;
	public static String CODE;
	public static String ACTION;
	public static String PARAM1;
	public static String PARAM2;
	public static String PARAM3;

	public static String ASP_BASE64;
	public static String ASP_MAKE;
	public static String ASP_PAYLOAD;
	public static String ASP_INDEX;
	public static String ASP_READDICT;
	public static String ASP_READFILE;
	public static String ASP_SAVEFILE;
	public static String ASP_DELETE;
	public static String ASP_RENAME;
	public static String ASP_RETIME;
	public static String ASP_NEWDICT;
	public static String ASP_UPLOAD;
	public static String ASP_DOWNLOAD;
	public static String ASP_SHELL;
	//test asp mdb 尚未合并
	public static String ASP_DB_MDB;
	public static String ASP_DB_MSSQL;
	public static String ASP_DB_MYSQL;

	
	public static String ASPX_BASE64;
	public static String ASPX_MAKE;
	public static String ASPX_INDEX;
	public static String ASPX_READDICT;
	public static String ASPX_READFILE;
	public static String ASPX_SAVEFILE;
	public static String ASPX_DELETE;
	public static String ASPX_RENAME;
	public static String ASPX_RETIME;
	public static String ASPX_NEWDICT;
	public static String ASPX_UPLOAD;
	public static String ASPX_DOWNLOAD;
	public static String ASPX_SHELL;
	public static String ASPX_DB_MSSQL;
	public static String ASPX_DB_MYSQL;
	public static String ASPX_DB_MDB;
	
	public static String PHP_BASE64;
	public static String PHP_MAKE;
	public static String PHP_INDEX;
	public static String PHP_READDICT;
	public static String PHP_READFILE;
	public static String PHP_SAVEFILE;
	public static String PHP_DELETE;
	public static String PHP_RENAME;
	public static String PHP_RETIME;
	public static String PHP_NEWDICT;
	public static String PHP_UPLOAD;
	public static String PHP_DOWNLOAD;
	public static String PHP_SHELL;
	public static String PHP_DB_MYSQL;
	
	public static String JSP_BASE64;
	public static String JSP_MAKE;
	public static String JSP_INDEX;
	public static String JSP_READDICT;
	public static String JSP_READFILE;
	public static String JSP_SAVEFILE;
	public static String JSP_DELETE;
	public static String JSP_RENAME;
	public static String JSP_RETIME;
	public static String JSP_NEWDICT;
	public static String JSP_UPLOAD;
	public static String JSP_DOWNLOAD;
	public static String JSP_SHELL;
	public static String JSP_DB_MYSQL;
	public static String JSP_DB_MSSQL;
	public static String JSP_DB_ORACLE;
	
	public static String CUS_BASE64;
	public static String CUS_MAKE;
	public static String CUS_INDEX;
	public static String CUS_READDICT;
	public static String CUS_READFILE;
	public static String CUS_SAVEFILE;
	public static String CUS_DELETE;
	public static String CUS_RENAME;
	public static String CUS_RETIME;
	public static String CUS_NEWDICT;
	public static String CUS_UPLOAD;
	public static String CUS_DOWNLOAD;
	public static String CUS_SHELL;
	public static String CUS_SHELL_SPL;
	public static String CUS_SHELL_SPR;
	
	public static String COMMON_SQL_STRING;
	
	public static String PASS;
	public static String SYSTEMSP;
	
	public static String PROXY_HOST;
	public static String PROXY_PORT;
	public static String PROXY_USER;
	public static String PROXY_PASS;
	public static String PROXY_TYPE;
	public static String PROXY_STATUS;
	
	public static String REQUEST_STATUS;
	public static String REQUEST_DATA;
}
