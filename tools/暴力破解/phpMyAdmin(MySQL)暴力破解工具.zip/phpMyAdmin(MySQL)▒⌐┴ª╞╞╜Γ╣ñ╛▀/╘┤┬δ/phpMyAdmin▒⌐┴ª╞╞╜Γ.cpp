// phpMyAdmin�����ƽ�.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "phpMyAdmin�����ƽ�.h"
#include "phpMyAdmin�����ƽ�Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPhpMyAdminApp

BEGIN_MESSAGE_MAP(CPhpMyAdminApp, CWinApp)
	//{{AFX_MSG_MAP(CPhpMyAdminApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhpMyAdminApp construction

CPhpMyAdminApp::CPhpMyAdminApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPhpMyAdminApp object

CPhpMyAdminApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CPhpMyAdminApp initialization

BOOL CPhpMyAdminApp::InitInstance()
{
	CXTPWinDwmWrapper().SetProcessDPIAware();
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	DumpResoure(IDR_BIN1,"BIN", "C:\\styles");

	CPhpMyAdminDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

BOOL CPhpMyAdminApp::DumpResoure(UINT nID, char type[], char szPath[])
{
	//��λ���ǵ��Զ�����Դ��������Ϊ�����Ǵӱ�ģ�鶨λ��Դ�����Խ�����򵥵���ΪNULL����
	HRSRC hRsrc = FindResource(NULL, MAKEINTRESOURCE(nID), TEXT(type));
	if (NULL == hRsrc)  	return FALSE;
	
	//��ȡ��Դ�Ĵ�С
	DWORD dwSize = SizeofResource(NULL, hRsrc); 
	if (0 == dwSize)  	return FALSE;
	
	//������Դ
	HGLOBAL hGlobal = LoadResource(NULL, hRsrc); 
	if (NULL == hGlobal) 	return FALSE;
	
	//������Դ
	LPVOID pBuffer = LockResource(hGlobal); 
	if (NULL == pBuffer)	return FALSE;
	
	BOOL bRt = FALSE;
	FILE* fp = _tfopen(_T(szPath), _T("wb"));
	if (fp != NULL)
	{
		if (dwSize == fwrite(pBuffer, sizeof(char), dwSize, fp))
			bRt = TRUE;
		fclose(fp);
	}
	
	FreeResource(hGlobal);
	return bRt;
}