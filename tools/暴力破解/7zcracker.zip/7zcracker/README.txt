7z Cracker 		by Justme2		V0.01	10.01.2010

			Release Notes

You need to download the 7za commandline tool.
You can get it here: https://sourceforge.net/projects/sevenzip/files/7-Zip/9.10%20beta/7za910.zip/download

Put the 7za.exe into the directory of the 7z Cracker
Put the 7z file to crack into the directory
Start 7zcracker.exe
Type in the filename of the archive including the extension (e.g. test.7z)
Press Enter

7zcracker will create a folder named est and a log file.
To guarantee that the file is unzipped 7zcracker will check for the est folder if it exists.

Please post a performance note on Sourceforge and Rate the Project.

Thank you

Justme2

